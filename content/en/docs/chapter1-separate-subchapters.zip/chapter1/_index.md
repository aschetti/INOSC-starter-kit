---
# Title, summary, and page position.
linktitle: 'Section I'
summary: ''
weight: 1
icon: book
icon_pack: fas
toc: false # remove the right sidebar for table of contents

# Page metadata.
title: 'Section I'
date: "2020-10-18"
type: book  # Do not modify.
---

## An introduction to Open Science Communities.