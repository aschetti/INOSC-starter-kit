---
title: 'I.1 Le rôle des communautés dans la transition vers la science ouverte'
linktitle: 'Partie I.1'
type: book
date: "2021-10-11"
toc: false # remove the right sidebar for table of contents
# Prev/next pager order (if `docs_section_pager` enabled in `params.toml`)
weight: 2
---


À première vue, la transition vers la SO peut sembler plutôt facile à réaliser. Pourquoi les gens n'adopteraient-ils pas ce formidable ensemble de nouvelles pratiques ? En réalité, cela ne demande rien de moins qu'un profond changement culturel dans le monde académique. Comme l'explique Brian Nosek dans [ce billet de blog](https://cos.io/blog/strategy-culture-change/), un changement culturel nécessite un ensemble d'ingrédients clés que l'on peut représenter sous forme de pyramide (*Figure 1*).

***

![La pyramide du changement culturel](./fig1.png "La pyramide du changement culturel")
***Figure 1**. La pyramide du changement culturel. Illustration de Brian Nosek (sous [licence CC BY](https://twitter.com/BrianNosek/status/1446528277271748611)), tirée du billet de blog [Strategy for Culture Change](https://www.cos.io/blog/strategy-for-culture-change)*

***

Au sommet de cette pyramide se trouve la **politique**. Pour un changement culturel en faveur de la SO dans le monde académique, des politiques publiques sont nécessaires pour la promouvoir et s'assurer que les incitations institutionnelles sont alignées en conséquence. Au bas de cette pyramide, nous trouvons l'**infrastructure** nécessaire. Il est essentiel de disposer d'une infrastructure fiable, flexible et ergonomique pour mettre en pratique la science ouverte. Les plateformes en ligne permettent de mettre en place des flux de travail collaboratifs (par ex. [Open Science Framework](https://cos.io/)), de stocker et partager des données, codes et autres résultats (voir également [EOSC](https://www.eosc-portal.eu/)) et des services de soutien, par exemple, ceux fournis par les services de documentation. Cependant, malgré les politiques récentes et les infrastructures disponibles, nous attendons toujours un véritable changement culturel. Qu'est-ce qui nous retient ? Ce défi se situe au niveau de la couche intermédiaire de la pyramide, les **communautés** qui rendent la SO normale. À l'heure actuelle, la communauté scientifique engagée dans la SO est relativement restreinte et se compose principalement de personnes qui ont déjà une certaine pratique de la SO. Ces pionniers de la SO jouent souvent un rôle consultatif en matière de politique et d'infrastructure. Bien que leur contribution soit extrêmement précieuse, ils peuvent négliger les obstacles rencontrés par les nouveaux venus dans la SO. Ces nouveaux venus représentent le champ scientifique dans son sens le plus large : il ne s'agit pas seulement d'étudiants ou de chercheurs en début de carrière, mais aussi de chercheurs senior qui sont habitués à un mode de travail pendant des décennies et qui s'intéressent maintenant à des pratiques plus ouvertes. Si l'on n'implique pas cette communauté plus large et si l'on ne fait pas appel à des objectifs et des valeurs partagés, la SO risque de devenir une perte de temps ou "une case de plus à cocher" au lieu d'enrichir les méthodes de travail de chacun. L'adoption à grande échelle de la SO dépend donc de la transition des pionniers à la majorité précoce et tardive (*Figure 2*).

***

![Cycle de diffusion de l'innovation selon Everett Rogers](./fig2.png "Cycle de diffusion de l'innovation selon Everett Rogers")
***Figure 2**. [Cycle de diffusion de l'innovation selon Everett Rogers](https://en.wikipedia.org/wiki/Technology_adoption_life_cycle#/media/File:DiffusionOfInnovation.png), indiquant les étapes par lesquelles passe généralement toute innovation : Innovateurs, Premiers adeptes, Majorité précoce, Majorité tardive, Retardataires.*

***

Tout changement culturel a besoin d'une masse critique pour remettre en question et modifier le *statu quo*, et l'apport des nouveaux venus est essentiel pour affiner la politique et l'infrastructure nécessaires pour parvenir à une adoption large de la SO. Le principal défi de la transition vers la science ouverte est donc un **défi social** : comment impliquer une masse critique de la communauté scientifique ? Si beaucoup vivent la transition vers l'ouverture comme libératrice et plus conforme à leurs motivations intrinsèques, d'autres sont plus réticents à changer pour plusieurs raisons. Il se peut qu'ils soient à l'aise dans leurs pratiques actuelles, qu'ils n'en voient pas les avantages, qu'ils considèrent que l'investissement n'en vaut pas la peine, ou qu'ils soient dépassés et frustrés par la surcharge d'information et l'absence de norme et de reconnaissance institutionnelle. Certains pourraient même penser que la SO n'est qu'une phase, et voudront attendre que cela se calme. Sauf que ça ne se calmera pas. La transition est bel et bien là et tous les chercheurs devront y faire face. Le moment est venu de construire et de façonner cette transition et, pour cela, nous avons besoin de la contribution de la communauté scientifique dans son ensemble.

C'est là que les Communautés science ouverte (en anglais *Open Science Communities* ou OSC) entrent en jeu. Il s'agit de communautés d'apprentissage par la base conçues pour une grande partie des chercheurs. Pour ce faire, nous rendons les OSC plus **visibles**, plus **accessibles**, et nous explorons les **obstacles et les exigences** qui se présentent aux nouveaux venus qui veulent ouvrir leurs pratiques. Pour une présentation plus détaillée du rôle des OSC dans la transition vers la science ouverte, veuillez lire notre [livre blanc](https://doi.org/10.31222/osf.io/7gct9/).

Pour mettre en place un changement mondial vers la SO, nous avons besoin de nombreuses OSC locales, à travers le monde. C'est avec ces objectifs en tête que nous avons créé ce kit de démarrage, pour vous inspirer et vous permettre de créer une OSC locale. La clé pour accélérer la transition vers la SO peut, littéralement, être entre vos mains.



[^1] : Le terme de "science" est utilisé ici dans son sens le plus large et inclut des domaines tels que les sciences humaines, les sciences sociales et l'ingénierie — soit toute forme d'érudition.
