---
title: 'I.3 Histoire et réussites de nos Communautés science ouverte'
linktitle: 'Partie I.3'
type: book
date: "2021-10-11"
toc: false # remove the right sidebar for table of contents
# Prev/next pager order (if `docs_section_pager` enabled in `params.toml`)
weight: 4
---

Pour un aperçu de la façon dont une OSC peut grandir, regardons comment les OSC des Pays-Bas ont progressé. La première OSC a été celle d'Utrecht ([OSCU](https://openscience-utrecht.com/)), lancée en 2018 à l'Université d'Utrecht par deux chercheurs passionnés par la SO. Ils ont commencé par rendre plus visibles les pratiques de SO dans leur université, en demandant à des collègues impliqués dans la SO de rejoindre la Communauté et en listant leurs expertises SO sur le site web. En outre, ils ont recruté des membres qui étaient intéressés par la SO, mais qui n'avaient pas d'expérience dans ce domaine. Ces membres pouvaient alors contacter leurs pairs plus expérimentés pour en savoir plus sur certaines pratiques. En outre, les membres de l'OSCU ont reçu un bulletin d'information mensuel et les fondateurs ont commencé à mettre en valeur la Communauté sur le campus et sur les médias sociaux. Au fil du temps, le nombre de membres a augmenté et l'OSCU a commencé à organiser une série d'ateliers sur des thèmes choisis par une enquête auprès de ses membres. En outre, les fondateurs ont créé un [tutoriel étape par étape](https://openscience-utrecht.com/community-blueprint/) décrivant comment ils ont lancé l'OSCU, afin d'aider les collègues d'autres universités à lancer une initiative similaire dans leur université. En un an, des collègues de plusieurs universités néerlandaises (*Figure 3*) ont lancé des OSC parallèles, fonctionnant sous un acronyme et un logo similaires et partageant un ensemble de Principes directeurs et un Code de conduite[^1].

Au bout d'un an, l'OSCU a obtenu un financement de l'Université d'Utrecht pour développer et soutenir ses activités, ce qui a conduit à la désignation d'ambassadeurs chargés de promouvoir la communauté dans leurs facultés respectives via les réunions de l'OSC-NL (OSC Pays-Bas). Après la première réunion OSC-NL, une pléthore d'ateliers et d'événements sur la SO ont été organisés bien au-delà d'Utrecht. Par exemple, au cours de la première année qui a suivi la participation à la première OSC-NL, la Communauté science ouverte de Groningen (OSCG) a lancé une pétition dans laquelle 244 membres du personnel de l'Université de Groningen ont indiqué être prêts à soutenir activement l'OSCG. Après son lancement officiel, l'OSCG a organisé six conférences et ateliers (par exemple sur la visualisation des données, le pré-enregistrement (*registered reports*) etc.), a lancé un [site Web](https://openscience-groningen.nl/), un [compte Twitter](https://twitter.com/OSCGroningen) et une [chaîne YouTube](https://www.youtube.com/channel/UCNqQuXVcwnnof_7QEIaabdQ), et a commencé à envoyer une lettre d'information bimestrielle à l'OSCG (227 abonnés). Plus récemment, en collaboration avec le service de documentation, ils ont mis en place un [Prix de la science ouverte](https://openscience-groningen.nl/call-for-submissions-open-research-awards/) annuel pour le personnel et les étudiants de l'université.   

En moins de deux ans, 11 Communautés science ouverte ont vu le jour aux Pays-Bas et deux en dehors des Pays-Bas (*Figure 4*), qui ont toutes organisé différentes activités et cherché où ils pouvaient contribuer le plus à faire avancer la SO dans leur université (voir *Encadré 1* pour un aperçu des réalisations). Si cette approche organique était rapide, amusante et efficace à court terme, elle manquait d'un objectif ou d'une stratégie globale claire. Les décisions étaient généralement prises de manière *ad hoc* (devrions-nous organiser un autre atelier ? ou lancer un blog ? ou… ou…) et il était difficile d'évaluer le succès de nos Communautés sur le terrain. Nous avons donc décidé de prendre du recul et de réfléchir à nos objectifs, stratégies et outils, que nous présentons maintenant dans ce kit de démarrage[^2].

> ***Encadré 1.** Réussites des Communautés science ouverte depuis 2018.*
> - OSC dans onze[^3] universités néerlandaises, totalisant plus de 700 membres (et ce n'est pas fini !)
> - deux OSC en dehors des Pays-Bas, en Suède et en Irlande
> - nombreux séminaires et événements de science ouverte, jusqu'à 75 participants
> - plusieurs blogs tenus sur divers sujets liés à la science ouverte (par exemple, ce billet ["10 mythes de la science ouverte"](https://openscience-groningen.nl/10-open-science-myths/)).
> - [Prix de la science ouverte](https://openscience-groningen.nl/call-for-submissions-open-research-awards/) lancé par l'OSCG
> - sollicitations fréquentes pour animer des conférences et des ateliers sur la science ouverte lors d'événements nationaux et internationaux
> - contribution à d'importantes demandes de financement en Europe et aux États-Unis
> - sollicitations fréquentes pour conseiller les décideurs locaux
> - sollicitations fréquentes pour promouvoir des ressources (bibliothèques universitaires, projet national ORCID)
> - reconnaissance au niveau local par les [présidents d'université](https://www.uu.nl/sites/default/files/uu-oaj-2019-2020-henk-kummeling.pdf) et les doyens et, au niveau international, par le [Center for Open Science](https://www.cos.io/blog/how-build-open-science-network-your-community) et la [Society for the Improvement of Psychological Science](https://improvingpsych.org/mission/awards/).

***

![INOSC](./fig4.png "Vue d'ensemble des Communautés science ouverte actuelles")
***Figure 4**. Vue d'ensemble des Communautés science ouverte actuelles. À la date de mai 2021, le Réseau international des Communautés science ouverte (en anglais *International Network of Open Science Communities* ou INOSC) compte 11 Communautés science ouverte aux Pays-Bas, 1 en Irlande, 1 en Suède et 1 en Arabie Saoudite. Image par [Anita Eerland](http://www.anitaeerland.com/about/), sous licence [CC BY-ND 3.0](https://creativecommons.org/licenses/by-nd/3.0/nl/deed.en).*

***

[^1] : Il est intéressant de noter que, bien que les OSC soient ouvertes aux membres de toutes les disciplines, les fondateurs de ces Communautés sont souvent des chercheurs dans le domaine des sciences sociales. Cela s'explique probablement par le fait que le discours autour de la SO est très vivant dans cette discipline, mais aussi parce que la plupart des coordinateurs des OSC participent aux mêmes événements. L'un des plus influents à cet égard est la réunion annuelle de la Society for the Improvement of Psychological Sciences ([SIPS](http://improvingpsych.org/)), où le format des OSC a été activement promu par les fondateurs de l'OSCU.
[^2] : Dans le cas de Loek Brinkman et Antonio Schettino, ce processus de réflexion a été inspiré par le programme [eLife Innovation Leaders](https://elifesciences.org/labs/ea8e2f51/introducing-innovation-leaders-2020), lui-même inspiré par [Mozilla Open Leaders](https://foundation.mozilla.org/en/initiatives/mozilla-open-leaders/).
[^3] : OSCA est une collaboration entre deux universités : l'Université d'Amsterdam (UvA) et la Vrije Universiteit Amsterdam (VU).
