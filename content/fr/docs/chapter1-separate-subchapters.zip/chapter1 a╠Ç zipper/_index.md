---
# Title, summary, and page position.
linktitle: 'Partie I'
summary: ''
weight: 1
icon: book
icon_pack: fas
toc: false # remove the right sidebar for table of contents

# Page metadata.
title: 'Partie I'
date: "2021-10-11"
type: book  # Do not modify.
---

## Une introduction aux Communautés science ouverte
