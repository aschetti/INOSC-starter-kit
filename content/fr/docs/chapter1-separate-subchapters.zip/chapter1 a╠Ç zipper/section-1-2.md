---
title: 'I.2 Notre format pour les Communautés science ouverte'
linktitle: 'Partie I.2'
type: book
date: "2021-10-11"
toc: false # remove the right sidebar for table of contents
# Prev/next pager order (if `docs_section_pager` enabled in `params.toml`)
weight: 3
---


Notre vision et notre mission sont :

> **Vision et mission**
>
> La science ouverte améliore la qualité, l'accessibilité et l'efficacité de la science, mais n'est **pas encore la norme** dans la recherche. Alors que des chercheurs pionniers développent et adoptent les pratiques de la science ouverte, la majorité s'en tient au *statu quo*. Pour *passer des pionniers à la pratique courante*, nous devons engager une part critique de la communauté académique.
>
> C'est ici que les Communautés science ouverte entrent en jeu.
>
> Les Communautés science ouverte offrent un lieu où **les nouveaux venus et les pairs expérimentés** interagissent, **s'inspirent mutuellement** pour intégrer les pratiques et les valeurs de la science ouverte dans leurs pratiques, et font un retour sur les feuilles de route, l'infrastructure et les services de soutien.
>
> Ensemble, nous faisons de la science ouverte une norme !  

La mission ci-dessus peut être décomposée en objectifs pratiques (*Figure 3*) :

> **Objectifs**
> - Accueillir les nouveaux venus à la science ouverte
> - Augmenter l'appropriation des pratiques de la science ouverte
> - Servir de terreau aux initiatives de science ouverte
> - Interagir avec les politiques, les infrastructures et les services de soutien
> - Favoriser les interactions entre le monde académique et la société

***

![Principales raisons d'être des OSC](./fig3.png "Principales raisons d'être des OSC")
***Figure 3**. Schéma présentant les principales raisons d'être d'une Communauté science ouverte (en légende).*

***

*Objectif n°&nbsp;1 - Accueillir les nouveaux venus à la science ouverte*  
L'objectif principal d'une OSC est d'accueillir les nouveaux venus dans le domaine de la SO et de proposer un espace où ils peuvent apprendre de leurs pairs et identifier les moyens de surmonter les difficultés lors de la transition vers des pratiques (plus) ouvertes. Une OSC est une communauté d'apprentissage : il n'est pas nécessaire d'avoir une quelconque expérience de la SO pour rejoindre la communauté, ni de s'engager formellement à adopter de telles pratiques. Ce qui unit les membres de la communauté, c'est leur intérêt pour la SO, affiché publiquement sur le site web de leur OSC.   
Pour interagir avec les nouveaux venus, il est crucial qu'ils connaissent l'existence de votre communauté. Vous devez être visible. De même, les nouveaux venus doivent être attirés par la communauté. Ils doivent se sentir chez eux. Il est essentiel de trouver le bon ton. Nous fournissons des consignes pratiques à cet égard dans la [*Partie II*]({{< ref "../chapter2/_index.md" >}}).

*Objectif n°&nbsp;2 - Augmenter l'appropriation des pratiques de la science ouverte*   
Augmenter l'appropriation des pratiques de la SO est la clé notre mission. Il s'agit  d'inciter les nouveaux venus à faire leurs premiers pas, mais aussi de consolider leurs pratiques actuelles de la SO parmi les collègues qui ont déjà changé (une partie de) leur méthode de travail. Notre principale stratégie consiste à faciliter l'échange de connaissances entre pairs. Dans la [*Partie II*]({{< ref "../chapter2/_index.md" >}}), nous fournissons plusieurs exemples concrets de formats qui favorisent l'échange de connaissances entre pairs.

*Objectif n°&nbsp;3 - Servir de terreau aux initiatives de science ouverte*
Le succès d'une communauté dépend des contributions de ses membres. Il est donc important de **permettre aux membres de lancer leurs propres initiatives** au sein de la communauté. Ces initiatives peuvent être facilitées en fournissant des lignes directrices, en les annonçant sur le site web, la *newsletter* et les réseaux sociaux et, si possible, en leur allouant un budget. Au lieu de proposer de nouvelles initiatives, les membres peuvent également transposer des formats qui ont fait leurs preuves dans d'autres OSC notamment. Des conseils pratiques et des exemples d'initiatives ayant fait leurs preuves sont détaillés dans la [*Partie II*]({{< ref "../chapitre2/_index.md" >}}).

*Objectif n°&nbsp;4 - Interagir avec les politiques, les infrastructures et les services de soutien*   
L'une des principales caractéristiques d'une OSC est qu'elle fonctionne **indépendamment** de la politique institutionnelle. Cela signifie que la communauté est une organisation autonome qui ne reçoit pas d'instructions, d'objectifs ou de tâches d'autres parties. Cependant, les OSC ne doivent pas fonctionner de manière isolée. Comme indiqué dans la [*Partie I.1*](#I.1-Le-rôle-des-communautés-dans-la-transition-vers-la-science-ouverte), les OSC ont leur place entre la politique et l'infrastructure. La politique prescrit ce qui est requis, souhaité et encouragé ; l'infrastructure détermine ce qui est possible ; mais la communauté décide comment les choses se font en pratique. Pour faciliter une transition en douceur vers la SO, toutes les parties prenantes doivent collaborer. C'est pourquoi le(s) coordinateur(s) de la OSC s'efforce(nt) de renforcer les liens avec les collègues occupant des postes de direction, en particulier ceux impliqués dans les **politiques institutionnelles, les infrastructures et les services de soutien**. Des exemples pratiques de collaboration avec ces acteurs sont abordés dans la [*Partie II*]({{< ref "../chapter2/_index.md" >}}).

*Objectif n°&nbsp;5 - Favoriser les interactions entre le monde académique et la société*
La SO est non seulement ouverte aux collègues du monde académique, mais aussi ouverte à la société. Nous encourageons donc les interactions entre les chercheurs et les acteurs de la société : société civile organisée, citoyens, patients, hommes et femmes politiques, entreprises. Une première étape consiste à rendre notre travail accessible à ces acteurs. Quand c'est possible, nous encourageons également à les impliquer à toutes les étapes du cycle de la recherche.

***

| Objectifs       | Public cible     | Stratégies et formats   |
| :------------- | :----------: | -----------: |
| Accueillir les nouveaux venus à la science ouverte | Nouveaux venus | Site web, newsletter, brochures, <br> *goodies*, réseaux sociaux, ton |
| Augmenter l'appropriation des pratiques de la science ouverte | Nouveaux venus et collègues expérimentés | Présentations flash, séminaires, <br> colloques, programmes de mentorat, forum |
| Servir de terreau aux initiatives de science ouverte | Nouveaux venus et collègues expérimentés | Initiatives des membres, initiatives ayant fait leurs preuves |
| Interagir avec les politiques, les infrastructures et les services de soutien | Présidents d'université, organes de direction, <br> doyens, bibliothécaires, informaticiens | Réunions de concertation régulières avec les parties prenantes |
| Favoriser les interactions entre le monde académique et la société | Chercheurs, société civile | Colloques, réunions d'information, festivals de science, communication en ligne |

***Table 1**. Objectifs et publics. Les stratégies et formats sont détaillées dans la [Partie II]({{< ref "../chapter2/_index.md" >}}).*

***
