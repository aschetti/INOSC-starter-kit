---
title: 'I.4 Appel à l'action'
linktitle: 'Partie I.4'
type: book
date: "2021-10-11"
toc: false # remove the right sidebar for table of contents
# Prev/next pager order (if `docs_section_pager` enabled in `params.toml`)
weight: 5
---

En tant que coordinateurs de la Communauté locale, nous sommes très heureux et fiers de ce que nous avons réalisé jusqu'à présent, mais nous voulons toujours plus[^1] ! C'est pourquoi nous encourageons nos collègues du monde entier à créer des OSC dans leurs universités ou centres de recherche, afin de créer un élan pour un changement de culture à l'échelle mondiale en faveur de la SO (*Figure 5*). Nous vous invitons donc à créer une OSC locale. N'hésitez pas à vous mettre en relation avec nous afin de partir d'un exemple éprouvé et de profiter de notre réseau actif de coordinateurs de Communautés pour échanger des expériences et des idées. En outre, au fur et à mesure que le réseau s'étend, nous serons à même de solliciter collectivement des financements (inter)nationaux et contribuer aux politiques (inter)nationales. Faire partie du réseau en expansion des OSC signifie que vous adhérez à nos Principes directeurs et à notre Code de conduite, mais que vous concevez et gérez votre Communauté comme bon vous semble, en tenant pleinement compte du contexte local. Ensemble, nous faisons de la SO la norme, au bénéfice de la science et de la société !

***

![Objectifs et raison d'être d'INOSC](./fig5.png "Objectifs et raison d'être d'INOSC")
***Figure 5**. Les objectifs et raison d'être de l'International Network of Open Science Communities (INOSC).*

***


[^1] : Comme le dit la chanson, [We've Only Just Begun](https://www.youtube.com/watch?v=__VQX2Xn7tI) !
